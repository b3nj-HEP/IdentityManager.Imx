import { ApiClient, ApiRequestOptions, EntityCollectionData, EntitySchema, FilterData, FkProviderItem, GroupInfo, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface DependencyToConfirm {
    Display?: string;
    ObjectType?: string;
    ObjectKey?: string;
    SortOrder: number;
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare enum OutstandingAction {
    Delete = 0,
    DeleteState = 1,
    Publish = 2
}
export interface OutstandingObject {
    ObjectKey?: string;
    ObjectType?: string;
    Display?: string;
    LastLogEntry?: Date;
    LastMethodRun?: string;
    CanPublish: boolean;
    CanPublishRestrictionReasons?: string[];
    CanDelete: boolean;
    CanDeleteRestrictionReasons?: string[];
}
export declare class TypedClient {
    readonly OpsupportNamespaces: OpsupportNamespacesWrapper;
    readonly OpsupportOutstandingTables: OpsupportOutstandingTablesWrapper;
    readonly OpsupportSyncDatastore: OpsupportSyncDatastoreWrapper;
    readonly OpsupportSyncJournal: OpsupportSyncJournalWrapper;
    readonly OpsupportSyncJournalfailure: OpsupportSyncJournalfailureWrapper;
    readonly OpsupportSyncJournalmessage: OpsupportSyncJournalmessageWrapper;
    readonly OpsupportSyncJournalobject: OpsupportSyncJournalobjectWrapper;
    readonly OpsupportSyncShell: OpsupportSyncShellWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class OpsupportNamespaces extends TypedEntity {
    readonly Ident_DPRNameSpace: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_DPRNameSpace'>;
}
export declare class OpsupportOutstandingTables extends TypedEntity {
    readonly TableName: IReadValue<string>;
    readonly CountOutstanding: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'TableName' | 'CountOutstanding'>;
}
export declare class OpsupportSyncDatastore extends TypedEntity {
    readonly OwnerObject: IWriteValue<string>;
    readonly Name: IReadValue<string>;
    readonly Data: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly ShellDisplay: IReadValue<string>;
    readonly SystemDisplay: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'OwnerObject' | 'Name' | 'Data' | 'DisplayName' | 'ShellDisplay' | 'SystemDisplay'>;
}
export declare class OpsupportSyncJournal extends TypedEntity {
    readonly CreationTime: IReadValue<Date>;
    readonly UID_DPRProjectionConfig: IReadValue<string>;
    readonly ProjectionConfigDisplay: IReadValue<string>;
    readonly ProjectionState: IReadValue<string>;
    readonly ProjectionStartInfoDisplay: IReadValue<string>;
    readonly UID_DPRJournal: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'CreationTime' | 'UID_DPRProjectionConfig' | 'ProjectionConfigDisplay' | 'ProjectionState' | 'ProjectionStartInfoDisplay' | 'UID_DPRJournal'>;
}
export declare class OpsupportSyncJournalfailure extends TypedEntity {
    readonly ObjectDisplay: IReadValue<string>;
    readonly ObjectState: IReadValue<string>;
    readonly Reason: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectDisplay' | 'ObjectState' | 'Reason'>;
}
export declare class OpsupportSyncJournalmessage extends TypedEntity {
    readonly MessageString: IReadValue<string>;
    readonly MessageContext: IReadValue<string>;
    readonly MessageSource: IReadValue<string>;
    readonly MessageType: IReadValue<string>;
    readonly SequenceNumber: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'MessageString' | 'MessageContext' | 'MessageSource' | 'MessageType' | 'SequenceNumber'>;
}
export declare class OpsupportSyncJournalobject extends TypedEntity {
    readonly SchemaTypeName: IReadValue<string>;
    readonly Method: IReadValue<string>;
    readonly ObjectDisplay: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'SchemaTypeName' | 'Method' | 'ObjectDisplay'>;
}
export declare class OpsupportSyncShell extends TypedEntity {
    readonly UID_DPRShell: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly NextSyncDate: IReadValue<Date>;
    readonly CountJournalFailure: IReadValue<number>;
    readonly LastSyncCountObjects: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_DPRShell' | 'DisplayName' | 'Description' | 'NextSyncDate' | 'CountJournalFailure' | 'LastSyncCountObjects'>;
}
export declare class OpsupportNamespacesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportNamespaces, unknown>>;
}
export declare class OpsupportOutstandingTablesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        namespace?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportOutstandingTables, unknown>>;
}
export declare class OpsupportSyncDatastoreWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        ElementObjectKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncDatastore, unknown>>;
}
export declare class OpsupportSyncJournalWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        shell?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncJournal, unknown>>;
}
export declare class OpsupportSyncJournalfailureWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncJournalfailure, unknown>>;
}
export declare class OpsupportSyncJournalmessageWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncJournalmessage, unknown>>;
}
export declare class OpsupportSyncJournalobjectWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncJournalobject, unknown>>;
}
export declare class OpsupportSyncShellWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        withfrozenjobs?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSyncShell, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    opsupport_namespaces_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_outstanding_dependencies_post(action: OutstandingAction, inputParameterName: string[]): MethodDescriptor<DependencyToConfirm[]>;
    opsupport_outstanding_journal_get(uid_journal: string): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_namespace_get(namespace: string): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_process_post(action: OutstandingAction, bulk: boolean, inputParameterName: string[]): MethodDescriptor<void>;
    opsupport_outstanding_table_get(tablename: string, namespace: string): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_tables_get(namespace: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_datastore_get(ElementObjectKey: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journal_get(shell: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalfailure_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalmessage_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalobject_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalobject_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    opsupport_sync_shell_get(withfrozenjobs: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_summary_get(journal: string): MethodDescriptor<Blob>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns all namespaces */
    opsupport_namespaces_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns dependencies for the supplied object keys. */
    opsupport_outstanding_dependencies_post(action: OutstandingAction, inputParameterName: string[], requestOptions?: ApiRequestOptions): Promise<DependencyToConfirm[]>;
    /** Returns all outstanding objects for a specific journal entry. */
    opsupport_outstanding_journal_get(uid_journal: string, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Returns all outstanding objects in the namespace. */
    opsupport_outstanding_namespace_get(namespace: string, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Applies the specified action to the supplied object keys. */
    opsupport_outstanding_process_post(action: OutstandingAction, bulk: boolean, inputParameterName: string[], requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all outstanding objects in a specific table. */
    opsupport_outstanding_table_get(tablename: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Returns all tables relevant to management of outstanding objects */
    opsupport_outstanding_tables_get(namespace: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_datastore_get(ElementObjectKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journal_get(shell: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalfailure_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalmessage_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalobject_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalobject_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    opsupport_sync_shell_get(withfrozenjobs: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_summary_get(journal: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
}
export declare class V2ApiClientMethodFactory {
    opsupport_namespaces_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_outstanding_dependencies_post(action: OutstandingAction, inputParameterName: string[], options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<DependencyToConfirm[]>;
    opsupport_outstanding_journal_get(uid_journal: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_namespace_get(namespace: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_process_post(action: OutstandingAction, inputParameterName: string[], options?: {
        bulk?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    opsupport_outstanding_table_get(tablename: string, options?: {
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<OutstandingObject[]>;
    opsupport_outstanding_tables_get(options?: {
        namespace?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_datastore_get(options?: {
        ElementObjectKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journal_get(options?: {
        shell?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalfailure_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalmessage_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalobject_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_journalobject_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    opsupport_sync_shell_get(options?: {
        withfrozenjobs?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_sync_summary_get(options?: {
        journal?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns all namespaces */
    opsupport_namespaces_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns dependencies for the supplied object keys. */
    opsupport_outstanding_dependencies_post(action: OutstandingAction, inputParameterName: string[], options?: {}, requestOptions?: ApiRequestOptions): Promise<DependencyToConfirm[]>;
    /** Returns all outstanding objects for a specific journal entry. */
    opsupport_outstanding_journal_get(uid_journal: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Returns all outstanding objects in the namespace. */
    opsupport_outstanding_namespace_get(namespace: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Applies the specified action to the supplied object keys. */
    opsupport_outstanding_process_post(action: OutstandingAction, inputParameterName: string[], options?: {
        bulk?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all outstanding objects in a specific table. */
    opsupport_outstanding_table_get(tablename: string, options?: {
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): Promise<OutstandingObject[]>;
    /** Returns all tables relevant to management of outstanding objects */
    opsupport_outstanding_tables_get(options?: {
        namespace?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_datastore_get(options?: {
        ElementObjectKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journal_get(options?: {
        shell?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalfailure_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalmessage_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalobject_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_journalobject_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    opsupport_sync_shell_get(options?: {
        withfrozenjobs?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_sync_summary_get(options?: {
        journal?: string;
    }, requestOptions?: ApiRequestOptions): Promise<Blob>;
}
