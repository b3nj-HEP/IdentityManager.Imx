import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntityKeysData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, ExtendedEntityWriteData, FilterData, FilterTreeData, FkCandidateRouteDto, FkProviderItem, GroupInfo, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityStateData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ParameterData, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface ApplicationAuthConfig {
    SsoAuthentifiers?: string[];
    ManualAuthentifiers?: string[];
    AdditionalAuthProps?: string;
    AuthenticationType?: AuthType;
    AllowPersistentAuth?: boolean;
    Product?: string;
    SecondaryAuth?: ISecondaryAuthProvider;
}
/** Represents application-specific configuration of method sets. */
export interface ApplicationMethodConfig {
    ApiProjects?: {
        [key: string]: ApplicationAuthConfig;
    };
    /** Gets or sets a flag indicating if all projects should be loaded, even the ones
not explicitly listed. */
    AllProjects: boolean;
}
export interface ATT_Person_SelfRegister_Config {
    WritablePropertiesForUnregisteredUsers?: string[];
}
export interface AttCaseDataRead {
    Data?: AttestationCaseData[];
    UiData?: AttestationCaseUiData[];
    Parameters?: {
        [key: string]: ParameterData[][];
    };
}
export interface AttestationCaseData {
    WorkflowHistory?: EntityCollectionData;
    WorkflowData?: EntityCollectionData;
    WorkflowSteps?: EntityCollectionData;
    CanSeeComplianceViolations: boolean;
    ComplianceViolations?: ComplianceViolation[];
    CanRecallDecision: boolean;
    CanRevokeDelegation: boolean;
    CanAskForHelp: boolean;
}
export interface AttestationCaseUiData {
    WorkflowActionHint?: string;
}
export interface AttestationConfig {
    /** Specify the default time period for newly created attestation policies within which attestors must make an approval decision on attestation cases of an attestation policy. This setting is set as default for creating new attestation policies and does not affect existing attestation policies. */
    VI_Attestation_NEW_POLICY_DEFAULT_SOLUTION_DAYS: number;
    /** Specify whether attestation cases for newly created attestation policies are automatically closed by default when new attestation cases are available. This setting is set as default for creating new attestation policies and does not affect existing attestation policies. */
    VI_Attestation_NEW_POLICY_DEFAULT_IS_AUTO_CLOSE_OLD_CASES: boolean;
    AttestationRunConfig?: RunStatisticsConfig;
    /** Specify whether frameworks can be assigned to attestation policies. */
    EnableComplianceFrameworks: boolean;
    ApprovalThreshold?: number;
    /** Before a negative decision is made, the user receives an indication of which assignments of the target identity will be lost as a result of the negative attestation decision. */
    AutoRemovalScope: boolean;
    /** Specify how many attestation cases of an attestation run must be closed for the attestation prediction to be displayed. Enter the value as a decimal value. Anything after the decimal mark is interpreted as a percentage. Use the point (.) as a decimal mark. */
    ProgressCalculationThreshold: number;
    /** If a policy affects more objects than this threshold, a warning is displayed. */
    PolicyObjectCountThreshold: number;
    IsAttestationEnabled: boolean;
    MitigatingControlsPerViolation: boolean;
    IsUserInChiefApprovalTeam: boolean;
}
export interface AttestationObjectData {
    TableName?: string;
    ParmData?: ParmData[];
}
export interface AttestationSnapshotData {
    Objects?: AttestationSnapshotObject[];
}
export interface AttestationSnapshotObject {
    Data?: EntityData;
    TableDisplay?: string;
}
export interface AttestationStepUpApprovalData {
    UidCases?: string[];
}
export interface AttUserConfig {
    CanClaimDevice: boolean;
}
export interface AuthConfig {
    Name?: string;
    Display?: string;
    ExternalLogoutUrl?: string;
    AuthProps?: AuthPropData[];
}
export interface AuthPropData {
    Name?: string;
    Display?: string;
    Type: AuthPropType;
    IsMandatory: boolean;
}
/** Authentication property types */
export declare enum AuthPropType {
    Info = 0,
    Edit = 1,
    Password = 2,
    Hidden = 3,
    Checkbox = 4,
    OAuth2Code = 5,
    NewPassword = 6
}
/** Represents the authentication status of a session. */
export interface AuthStatus {
    /** Returns the primary (database) authentication status. */
    PrimaryAuth?: PrimaryAuthStatus;
    /** Returns the authentication status for the second factor. */
    SecondaryAuth?: SecondaryAuthStatus;
    /** Returns the expiration date for the current authentication. */
    AuthValidUntil?: Date;
    /** Returns a URL to use for logging out from an external authentication provider. */
    ExternalLogoutUrl?: string;
    /** Returns the currently active culture for interface strings. */
    Culture?: string;
    /** Returns the currently active culture for value formatting. */
    CultureFormat?: string;
}
export declare enum AuthType {
    Default = 0,
    AllManualModules = 1,
    FixedCredentials = 2
}
export interface CandidateData {
    ParameterName?: string;
    Candidates?: FkCandidateRouteDto;
}
export interface CaptchaCode {
    /** Represents the code entered by the user. */
    Code?: string;
}
export interface ComplianceViolation {
    DisplayPerson?: string;
    DisplayRule?: string;
    Description?: string;
    IsNoEffectivePerson: boolean;
    IsExceptionAllowed: boolean;
    ContributingEntitlements?: ContributingEntitlement[];
    MitigatingControls?: MitigatingControl[];
}
export interface ConfigData {
    MethodConfig?: {
        [key: string]: ISessionAuthDbConfig;
    };
    ApplicationConfig?: ApplicationMethodConfig;
}
export interface ContributingEntitlement {
    Type?: string;
    Key?: string;
    Display?: string;
    Sources?: ContributingEntitlement[];
}
export interface DecisionInput {
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
export interface DenyDecisionInput {
    Reason?: string;
    UidJustification?: string;
}
export interface DirectDecisionInput {
    Reason?: string;
    Offset: number;
}
export interface EntitlementLossDto {
    Table?: string;
    Display?: string;
    ObjectDisplay?: string;
    Person?: string;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfAttCaseDataRead extends EntityCollectionData {
    ExtendedData?: AttCaseDataRead;
}
export interface ExtendedEntityCollectionDataOfPolicyFilterDataOf extends EntityCollectionData {
    ExtendedData?: PolicyFilterData[];
}
export interface ExtendedEntityWriteDataOfCaptchaCode extends EntityWriteData {
    ExtendedData?: CaptchaCode;
}
export interface ExtendedEntityWriteDataOfIDictionaryOfStringAndIReadOnlyListOfIReadOnlyListOfEntityWriteDataColumn extends EntityWriteData {
    ExtendedData?: {
        [key: string]: EntityWriteDataColumn[][];
    };
}
export interface ExtendedInteractiveEntityDataOfPolicyFilterDataOf extends InteractiveEntityData {
    ExtendedData?: PolicyFilterData[];
}
export interface ExtendedInteractiveEntityWriteDataOfPolicyFilterOf extends InteractiveEntityWriteData {
    ExtendedData?: PolicyFilter[];
}
export interface ExtendRunInput {
    Reason?: string;
    ProlongateUntil: Date;
}
export interface FeatureConfig {
    EnableSetPasswords: boolean;
    EnableSystemStatus: boolean;
}
export interface ImxConfig {
    CompanyLogoUrl?: string;
    ProductName?: string;
    ProductVersion?: string;
}
export interface ISecondaryAuthProvider {
    Key: string;
    Display: any;
}
export interface ISessionAuthDbConfig {
    SsoAuthentifiers: any;
    ManualAuthentifiers: any;
    AdditionalAuthProps: any;
    AuthenticationType: any;
    Product: string;
    ExcludedAuthentifiers: any;
    SecondaryAuth: any;
    AllowUsersWithoutSecondFactor: boolean;
    AllowPersistentAuth: boolean;
    AuthProviders: any;
}
export interface MitigatingControl {
    Uid?: string;
    Display?: string;
}
export interface OtherApproverInput {
    Reason?: string;
    UidPerson?: string;
}
export interface ParmData {
    Uid?: string;
    UidObject?: string;
    Display?: string;
    RequiredParameter?: string;
    TableName?: string;
    ColumnName?: string;
    Options?: ParmOpt[];
}
export interface ParmOpt {
    Uid?: string;
    Display?: string;
}
export interface PasscodeInput {
    PassCode?: string;
}
export interface PersonActivationDto {
    Culture?: string;
    CentralAccount?: string;
    ApprovalState: number;
}
export interface PolicyFilter {
    Elements?: PolicyFilterElement[];
    ConcatenationType?: string;
}
export interface PolicyFilterData {
    IsReadOnly: boolean;
    Filter?: PolicyFilter;
    InfoDisplay?: string[][];
}
export interface PolicyFilterElement {
    ParameterName?: string;
    AttestationSubType?: string;
    ParameterValue?: string;
    ParameterValue2?: string;
}
export interface PolicyStartInput {
    ObjectKeys?: string[];
}
export interface PrimaryAuthStatus {
    /** Returns the display name of the authenticated user. */
    Display?: string;
    /** Returns the unique identifier of the associated identity, if any. */
    Uid?: string;
    IsAuthenticated: boolean;
    /** Returns the time of the authentication. */
    AuthTime: Date;
}
export interface ProjectConfig {
    CandidateConfig?: {
        [key: string]: CandidateData[];
    };
    /** Enter the instrumentation key required to log metrics to App Insights. */
    AppInsightsKey?: string;
    /** Specify whether the web application sends browser notifications (for example, for pending requests or pending attestations). Users can still deactivate browser notifications. */
    VI_Common_EnableNotifications: boolean;
    /** Specify whether images are resized automatically when uploaded to the server. */
    EnableImageResizing: boolean;
    /** Enter the site key (public key) for reCAPTCHA integration. */
    RecaptchaPublicKey?: string;
    DefaultPageSize: number;
    /** Specify how many of the previous days to take into account by default when generating reports. */
    DefaultHistoryLengthDays: number;
}
export interface PwoQueryInput {
    UidPerson?: string;
    Text?: string;
}
export interface ReasonInput {
    Reason?: string;
}
export interface RunStatisticsConfig {
    /** Specify the threshold up to which progress of attestation runs is categorized bad. Attestation runs with an estimated progress lower or equal to this value are categorized bad. Enter the value as a decimal value. Anything after the decimal mark is interpreted as a percentage. Use the point (.) as a decimal mark. */
    LimitBad: number;
    /** Specify the threshold above which progress of attestation runs is categorized good. Attestation runs with an estimated progress higher than this value are categorized good. Enter the value as a decimal value. Anything after the decimal mark is interpreted as a percentage. Use the point (.) as a decimal mark. */
    LimitGood: number;
}
export interface SecondaryAuthStatus {
    /** Returns a flag indicating if the second authentication factor has succeeded. */
    IsAuthenticated: boolean;
    ErrorMessage?: string;
    /** Returns a flag indicating whether two-factor authentication is enabled.
If this value is false, two-factor authentication is not required. */
    IsEnabled: boolean;
    /** Returns the name of the two-factor authentication provider. */
    Name?: string;
}
export interface SelfRegisterConfig {
    SelfRegistrationEnabled: boolean;
}
export interface SendReminderInput {
    UidRuns?: string[];
    UidPerson?: string[];
    Message?: string;
}
export interface SessionResponse {
    Status?: AuthStatus;
    Config?: AuthConfig[];
}
export declare class TypedClient {
    readonly PortalAttestationApprove: PortalAttestationApproveWrapper;
    readonly PortalAttestationApproveParameterCandidates: PortalAttestationApproveParameterCandidatesWrapper;
    readonly PortalAttestationCase: PortalAttestationCaseWrapper;
    readonly PortalAttestationCaseHistory: PortalAttestationCaseHistoryWrapper;
    readonly PortalAttestationCaseParameterCandidates: PortalAttestationCaseParameterCandidatesWrapper;
    readonly PortalAttestationFilterCandidates: PortalAttestationFilterCandidatesWrapper;
    readonly PortalAttestationFilterMatchingobjects: PortalAttestationFilterMatchingobjectsWrapper;
    readonly PortalAttestationObject: PortalAttestationObjectWrapper;
    readonly PortalAttestationPersondecision: PortalAttestationPersondecisionWrapper;
    readonly PortalAttestationPolicy: PortalAttestationPolicyWrapper;
    readonly PortalAttestationPolicyEdit: PortalAttestationPolicyEditWrapper;
    readonly PortalAttestationPolicyEditInteractive: PortalAttestationPolicyEditInteractiveWrapper;
    readonly PortalAttestationRun: PortalAttestationRunWrapper;
    readonly PortalAttestationRunApprovers: PortalAttestationRunApproversWrapper;
    readonly PortalAttestationSchedules: PortalAttestationSchedulesWrapper;
    readonly PortalAttestationWorkflow: PortalAttestationWorkflowWrapper;
    readonly PortalCandidatesAttestationpolicygroup: PortalCandidatesAttestationpolicygroupWrapper;
    readonly PortalCandidatesCompliancearea: PortalCandidatesComplianceareaWrapper;
    readonly PortalCandidatesDialogtimezone: PortalCandidatesDialogtimezoneWrapper;
    readonly PortalCandidatesMitigatingcontrol: PortalCandidatesMitigatingcontrolWrapper;
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalCandidatesQbmculture: PortalCandidatesQbmcultureWrapper;
    readonly PortalClaimdeviceDevices: PortalClaimdeviceDevicesWrapper;
    readonly RegisterPerson: RegisterPersonWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAttestationApprove extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly IsReserved: IReadValue<boolean>;
    readonly PeerGroupFactor: IReadValue<number>;
    readonly IsCrossFunctional: IReadValue<boolean>;
    readonly DecisionLevel: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly PropertyInfo1: IReadValue<string>;
    readonly PropertyInfo2: IReadValue<string>;
    readonly PropertyInfo3: IReadValue<string>;
    readonly PropertyInfo4: IReadValue<string>;
    readonly ReportType: IReadValue<string>;
    readonly RiskIndex: IReadValue<number>;
    readonly StructureDisplay1: IReadValue<string>;
    readonly StructureDisplay2: IReadValue<string>;
    readonly StructureDisplay3: IReadValue<string>;
    readonly ToSolveTill: IReadValue<Date>;
    readonly UID_AttestationPolicy: IReadValue<string>;
    readonly IsNotApprovedBefore: IReadValue<boolean>;
    readonly UID_QERWorkingMethod: IReadValue<string>;
    readonly UID_AttestationRun: IReadValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly IsApproveRequiresMfa: IReadValue<boolean>;
    readonly DisplayType: IReadValue<string>;
    readonly AttestationState: IReadValue<string>;
    readonly MControls: IWriteValue<string>;
    readonly UiText: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsReserved' | 'PeerGroupFactor' | 'IsCrossFunctional' | 'DecisionLevel' | 'XDateInserted' | 'PropertyInfo1' | 'PropertyInfo2' | 'PropertyInfo3' | 'PropertyInfo4' | 'ReportType' | 'RiskIndex' | 'StructureDisplay1' | 'StructureDisplay2' | 'StructureDisplay3' | 'ToSolveTill' | 'UID_AttestationPolicy' | 'IsNotApprovedBefore' | 'UID_QERWorkingMethod' | 'UID_AttestationRun' | 'UID_PersonHead' | 'IsApproveRequiresMfa' | 'DisplayType' | 'AttestationState' | 'MControls' | 'UiText'>;
}
export declare class PortalAttestationApproveParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalAttestationCase extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly IsReserved: IReadValue<boolean>;
    readonly DecisionLevel: IReadValue<number>;
    readonly PropertyInfo1: IReadValue<string>;
    readonly PropertyInfo2: IReadValue<string>;
    readonly PropertyInfo3: IReadValue<string>;
    readonly PropertyInfo4: IReadValue<string>;
    readonly ReportType: IReadValue<string>;
    readonly RiskIndex: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly StructureDisplay1: IReadValue<string>;
    readonly StructureDisplay2: IReadValue<string>;
    readonly StructureDisplay3: IReadValue<string>;
    readonly ToSolveTill: IReadValue<Date>;
    readonly UID_AttestationPolicy: IReadValue<string>;
    readonly IsNotApprovedBefore: IReadValue<boolean>;
    readonly UID_AttestationRun: IReadValue<string>;
    readonly UID_QERWorkingMethod: IReadValue<string>;
    readonly IsApproveRequiresMfa: IReadValue<boolean>;
    readonly AttestationState: IReadValue<string>;
    readonly MControls: IReadValue<string>;
    readonly UiText: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsReserved' | 'DecisionLevel' | 'PropertyInfo1' | 'PropertyInfo2' | 'PropertyInfo3' | 'PropertyInfo4' | 'ReportType' | 'RiskIndex' | 'XDateInserted' | 'StructureDisplay1' | 'StructureDisplay2' | 'StructureDisplay3' | 'ToSolveTill' | 'UID_AttestationPolicy' | 'IsNotApprovedBefore' | 'UID_AttestationRun' | 'UID_QERWorkingMethod' | 'IsApproveRequiresMfa' | 'AttestationState' | 'MControls' | 'UiText'>;
}
export declare class PortalAttestationCaseHistory extends TypedEntity {
    readonly DateHead: IReadValue<Date>;
    readonly DecisionType: IReadValue<string>;
    readonly DisplayPersonHead: IReadValue<string>;
    readonly Ident_PWODecisionStep: IReadValue<string>;
    readonly IsDecisionBySystem: IReadValue<boolean>;
    readonly IsToHideInHistory: IReadValue<boolean>;
    readonly ReasonHead: IReadValue<string>;
    readonly RulerLevel: IReadValue<number>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly UID_PersonRelated: IReadValue<string>;
    readonly UID_PWODecisionRule: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DateHead' | 'DecisionType' | 'DisplayPersonHead' | 'Ident_PWODecisionStep' | 'IsDecisionBySystem' | 'IsToHideInHistory' | 'ReasonHead' | 'RulerLevel' | 'UID_PersonHead' | 'UID_PersonRelated' | 'UID_PWODecisionRule' | 'UID_QERJustification' | 'XDateInserted'>;
}
export declare class PortalAttestationCaseParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalAttestationFilterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalAttestationFilterMatchingobjects extends TypedEntity {
    readonly Key: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Key'>;
}
export declare class PortalAttestationObject extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly UID_AttestationType: IReadValue<string>;
    readonly UID_DialogTable: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'UID_AttestationType' | 'UID_DialogTable'>;
}
export declare class PortalAttestationPersondecision extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly OrderNumber: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'OrderNumber'>;
}
export declare class PortalAttestationPolicy extends TypedEntity {
    readonly UID_PersonOwner: IReadValue<string>;
    readonly UID_AttestationObject: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly UID_DialogSchedule: IReadValue<string>;
    readonly IsInActive: IReadValue<boolean>;
    readonly IsOob: IReadValue<boolean>;
    readonly CountCases: IReadValue<number>;
    readonly CountOpenCases: IReadValue<number>;
    readonly OverdueCases: IReadValue<number>;
    readonly NextRun: IReadValue<Date>;
    readonly IsProcessing: IReadValue<boolean>;
    readonly Attestators: IReadValue<string>;
    readonly Areas: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonOwner' | 'UID_AttestationObject' | 'Description' | 'UID_DialogSchedule' | 'IsInActive' | 'IsOob' | 'CountCases' | 'CountOpenCases' | 'OverdueCases' | 'NextRun' | 'IsProcessing' | 'Attestators' | 'Areas'>;
}
export declare class PortalAttestationPolicyEdit extends WriteExtTypedEntity<PolicyFilter[]> {
    readonly UID_PersonOwner: IWriteValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AttestationPolicy: IWriteValue<string>;
    readonly IsApproveRequiresMfa: IWriteValue<boolean>;
    readonly IsAutoCloseOldCases: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsShowElementsInvolved: IWriteValue<boolean>;
    readonly LimitOfOldCases: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SolutionDays: IWriteValue<number>;
    readonly UID_AttestationObject: IWriteValue<string>;
    readonly UID_AttestationPolicyGroup: IWriteValue<string>;
    readonly UID_DialogCulture: IWriteValue<string>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly UID_QERPickCategory: IWriteValue<string>;
    readonly NextRun: IReadValue<Date>;
    readonly IsPickCategoryMismatch: IReadValue<boolean>;
    readonly IsOob: IReadValue<boolean>;
    readonly CountOpenCases: IReadValue<number>;
    readonly IsPolicyWithRemove: IReadValue<boolean>;
    readonly Attestators: IWriteValue<string>;
    readonly Areas: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonOwner' | 'Description' | 'Ident_AttestationPolicy' | 'IsApproveRequiresMfa' | 'IsAutoCloseOldCases' | 'IsInActive' | 'IsShowElementsInvolved' | 'LimitOfOldCases' | 'RiskIndex' | 'SolutionDays' | 'UID_AttestationObject' | 'UID_AttestationPolicyGroup' | 'UID_DialogCulture' | 'UID_DialogSchedule' | 'UID_PWODecisionMethod' | 'UID_QERPickCategory' | 'NextRun' | 'IsPickCategoryMismatch' | 'IsOob' | 'CountOpenCases' | 'IsPolicyWithRemove' | 'Attestators' | 'Areas'>;
}
export declare class PortalAttestationPolicyEditInteractive extends WriteExtTypedEntity<PolicyFilter[]> {
    readonly UID_PersonOwner: IWriteValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AttestationPolicy: IWriteValue<string>;
    readonly IsApproveRequiresMfa: IWriteValue<boolean>;
    readonly IsAutoCloseOldCases: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsShowElementsInvolved: IWriteValue<boolean>;
    readonly LimitOfOldCases: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SolutionDays: IWriteValue<number>;
    readonly UID_AttestationObject: IWriteValue<string>;
    readonly UID_AttestationPolicyGroup: IWriteValue<string>;
    readonly UID_DialogCulture: IWriteValue<string>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly UID_QERPickCategory: IWriteValue<string>;
    readonly NextRun: IReadValue<Date>;
    readonly IsPickCategoryMismatch: IReadValue<boolean>;
    readonly IsOob: IReadValue<boolean>;
    readonly CountOpenCases: IReadValue<number>;
    readonly IsPolicyWithRemove: IReadValue<boolean>;
    readonly Attestators: IWriteValue<string>;
    readonly Areas: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonOwner' | 'Description' | 'Ident_AttestationPolicy' | 'IsApproveRequiresMfa' | 'IsAutoCloseOldCases' | 'IsInActive' | 'IsShowElementsInvolved' | 'LimitOfOldCases' | 'RiskIndex' | 'SolutionDays' | 'UID_AttestationObject' | 'UID_AttestationPolicyGroup' | 'UID_DialogCulture' | 'UID_DialogSchedule' | 'UID_PWODecisionMethod' | 'UID_QERPickCategory' | 'NextRun' | 'IsPickCategoryMismatch' | 'IsOob' | 'CountOpenCases' | 'IsPolicyWithRemove' | 'Attestators' | 'Areas'>;
}
export declare class PortalAttestationRun extends TypedEntity {
    readonly UID_AttestationPolicy: IReadValue<string>;
    readonly PolicyProcessed: IReadValue<Date>;
    readonly CountChunksUnderConstruction: IReadValue<number>;
    readonly DueDate: IReadValue<Date>;
    readonly PendingCases: IReadValue<number>;
    readonly ClosedCases: IReadValue<number>;
    readonly GrantedCases: IReadValue<number>;
    readonly DeniedCases: IReadValue<number>;
    readonly CasesAbortedBySystem: IReadValue<number>;
    readonly DelegatedCases: IReadValue<number>;
    readonly EscalatedCases: IReadValue<number>;
    readonly NewCases: IReadValue<number>;
    readonly Speed: IReadValue<number>;
    readonly AbortedBySystem: IReadValue<number>;
    readonly Delay: IReadValue<number>;
    readonly Progress: IReadValue<number>;
    readonly SecondsGone: IReadValue<number>;
    readonly SecondsLeft: IReadValue<number>;
    readonly RunCategory: IReadValue<string>;
    readonly ForecastClosedCases: IReadValue<number>;
    readonly ForecastProgress: IReadValue<number>;
    readonly ForecastRemainingDays: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AttestationPolicy' | 'PolicyProcessed' | 'CountChunksUnderConstruction' | 'DueDate' | 'PendingCases' | 'ClosedCases' | 'GrantedCases' | 'DeniedCases' | 'CasesAbortedBySystem' | 'DelegatedCases' | 'EscalatedCases' | 'NewCases' | 'Speed' | 'AbortedBySystem' | 'Delay' | 'Progress' | 'SecondsGone' | 'SecondsLeft' | 'RunCategory' | 'ForecastClosedCases' | 'ForecastProgress' | 'ForecastRemainingDays'>;
}
export declare class PortalAttestationRunApprovers extends TypedEntity {
    readonly UID_PersonHead: IReadValue<string>;
    readonly PendingCases: IReadValue<number>;
    readonly ClosedCases: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonHead' | 'PendingCases' | 'ClosedCases'>;
}
export declare class PortalAttestationSchedules extends TypedEntity {
    readonly LastRun: IReadValue<Date>;
    readonly NextRun: IReadValue<Date>;
    readonly Frequency: IReadValue<number>;
    readonly FrequencyType: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly Enabled: IWriteValue<boolean>;
    readonly FrequencySubType: IWriteValue<string>;
    readonly StartTime: IWriteValue<string>;
    readonly UID_DialogTimeZone: IWriteValue<string>;
    readonly DayOfYear: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'LastRun' | 'NextRun' | 'Frequency' | 'FrequencyType' | 'Description' | 'Enabled' | 'FrequencySubType' | 'StartTime' | 'UID_DialogTimeZone' | 'DayOfYear'>;
}
export declare class PortalAttestationWorkflow extends TypedEntity {
    readonly LevelNumber: IReadValue<number>;
    readonly LevelDisplay: IReadValue<string>;
    readonly Ident_PWODecisionStep: IReadValue<string>;
    readonly SubLevelNumber: IReadValue<number>;
    readonly DirectSteps: IReadValue<string>;
    readonly PositiveSteps: IReadValue<number>;
    readonly NegativeSteps: IReadValue<number>;
    readonly CountApprover: IReadValue<number>;
    readonly EscalationSteps: IReadValue<number>;
    readonly UID_PWODecisionRule: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'LevelNumber' | 'LevelDisplay' | 'Ident_PWODecisionStep' | 'SubLevelNumber' | 'DirectSteps' | 'PositiveSteps' | 'NegativeSteps' | 'CountApprover' | 'EscalationSteps' | 'UID_PWODecisionRule'>;
}
export declare class PortalCandidatesAttestationpolicygroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AttestationPolicyGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AttestationPolicyGroup'>;
}
export declare class PortalCandidatesCompliancearea extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_ComplianceArea: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_ComplianceArea'>;
}
export declare class PortalCandidatesDialogtimezone extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DialogTimeZone: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DialogTimeZone'>;
}
export declare class PortalCandidatesMitigatingcontrol extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_MitigatingControl: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_MitigatingControl'>;
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
export declare class PortalCandidatesQbmculture extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DialogCulture: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DialogCulture'>;
}
export declare class PortalClaimdeviceDevices extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class RegisterPerson extends WriteExtTypedEntity<CaptchaCode> {
    readonly CentralAccount: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'CentralAccount' | 'DefaultEmailAddress'>;
}
export declare class PortalAttestationApproveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        Escalation?: boolean;
        objecttable?: string;
        objectuid?: string;
        uid_attestationcase?: string;
        uid_attestationhelper?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationApprove, AttCaseDataRead>>;
    Put(inputParameterName: PortalAttestationApprove, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationApprove, AttCaseDataRead>>;
}
export declare class PortalAttestationApproveParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalAttestationApproveParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationApproveParameterCandidates, unknown>>;
}
export declare class PortalAttestationCaseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        objecttable?: string;
        objectuid?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationCase, AttCaseDataRead>>;
}
export declare class PortalAttestationCaseHistoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidcase: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationCaseHistory, unknown>>;
}
export declare class PortalAttestationCaseParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalAttestationCaseParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationCaseParameterCandidates, unknown>>;
}
export declare class PortalAttestationFilterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidattestationparm: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationFilterCandidates, unknown>>;
}
export declare class PortalAttestationFilterMatchingobjectsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidattestationobject: string, parametersOptional?: {
        policyfilter?: PolicyFilter;
        uidpickcategory?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationFilterMatchingobjects, unknown>>;
}
export declare class PortalAttestationObjectWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationObject, unknown>>;
}
export declare class PortalAttestationPersondecisionWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidattestationcase: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPersondecision, unknown>>;
}
export declare class PortalAttestationPolicyWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        OnlyActivePolicies?: string;
        ScheduleType?: string;
        mypolicies?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicy, unknown>>;
}
export declare class PortalAttestationPolicyEditWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        mypolicies?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEdit, PolicyFilterData[]>>;
    Delete(UID_AttestationPolicy: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEdit, PolicyFilterData[]>>;
}
export declare class PortalAttestationPolicyEditInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAttestationPolicyEditInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEditInteractive, PolicyFilterData[]>>;
    Delete(inputParameterName: PortalAttestationPolicyEditInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEditInteractive, PolicyFilterData[]>>;
    Get_byid(UID_AttestationPolicy: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEditInteractive, PolicyFilterData[]>>;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationPolicyEditInteractive, PolicyFilterData[]>>;
}
export declare class PortalAttestationRunWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withpendingcases?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationRun, unknown>>;
}
export declare class PortalAttestationRunApproversWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidrun: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationRunApprovers, unknown>>;
}
export declare class PortalAttestationSchedulesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationSchedules, unknown>>;
    Put(inputParameterName: PortalAttestationSchedules, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationSchedules, unknown>>;
}
export declare class PortalAttestationWorkflowWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidattestationcase: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAttestationWorkflow, unknown>>;
}
export declare class PortalCandidatesAttestationpolicygroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAttestationpolicygroup, unknown>>;
}
export declare class PortalCandidatesComplianceareaWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesCompliancearea, unknown>>;
}
export declare class PortalCandidatesDialogtimezoneWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesDialogtimezone, unknown>>;
}
export declare class PortalCandidatesMitigatingcontrolWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesMitigatingcontrol, unknown>>;
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalCandidatesQbmcultureWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQbmculture, unknown>>;
}
export declare class PortalClaimdeviceDevicesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalClaimdeviceDevices, unknown>>;
}
export declare class RegisterPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): RegisterPerson;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(inputParameterName: RegisterPerson, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<RegisterPerson, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    admin_config_get(): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): MethodDescriptor<ApplicationMethodConfig>;
    imx_config_get(): MethodDescriptor<ImxConfig>;
    opsupport_config_get(): MethodDescriptor<ProjectConfig>;
    opsupport_featureconfig_get(): MethodDescriptor<FeatureConfig>;
    passwordreset_activation_confirm_post(inputParameterName: PasscodeInput): MethodDescriptor<SessionResponse>;
    passwordreset_activation_init_post(uidcase: string): MethodDescriptor<PersonActivationDto>;
    passwordreset_activation_resendemail_post(): MethodDescriptor<void>;
    portal_attestation_additional_post(uidcase: string, inputParameterName: OtherApproverInput): MethodDescriptor<void>;
    portal_attestation_answerquery_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_approve_get(Escalation: boolean, objecttable: string, objectuid: string, uid_attestationcase: string, uid_attestationhelper: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, attestationtype: string, uidpolicy: string, type: string, risk: string): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_approve_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_approve_losspreview_get(uid_case: string): MethodDescriptor<EntitlementLossDto[]>;
    portal_attestation_approve_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_attestation_approve_datamodel_get(Escalation: boolean, objecttable: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_approve_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, attestationtype: string, uidpolicy: string, type: string, risk: string, Escalation: boolean): MethodDescriptor<GroupInfo[]>;
    portal_attestation_approve_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_attestation_approve_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_attestation_case_get(objecttable: string, objectuid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, attestationtype: string, uidpolicy: string, type: string, risk: string): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_case_datamodel_get(objecttable: string, objectuid: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_case_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, attestationtype: string, uidpolicy: string, type: string, risk: string, objecttable: string, objectuid: string): MethodDescriptor<GroupInfo[]>;
    portal_attestation_case_history_get(uidcase: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_case_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_attestation_case_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_attestation_config_get(): MethodDescriptor<AttestationConfig>;
    portal_attestation_decide_post(uidcase: string, inputParameterName: DecisionInput): MethodDescriptor<void>;
    portal_attestation_denydecision_post(uidcase: string, inputParameterName: DenyDecisionInput): MethodDescriptor<void>;
    portal_attestation_directdecision_post(uidcase: string, inputParameterName: DirectDecisionInput): MethodDescriptor<void>;
    portal_attestation_escalate_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_filter_candidates_get(uidattestationparm: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_filter_matchingobjects_get(policyfilter: PolicyFilter, uidpickcategory: string, uidattestationobject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_filter_model_get(uidobject: string): MethodDescriptor<AttestationObjectData>;
    portal_attestation_insteadof_post(uidcase: string, inputParameterName: OtherApproverInput): MethodDescriptor<void>;
    portal_attestation_managerattestation_post(): MethodDescriptor<void>;
    portal_attestation_object_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_persondecision_get(uidattestationcase: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, OnlyActivePolicies: string, ScheduleType: string, mypolicies: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_report_get(uidpolicy: string, uidrun: string): MethodDescriptor<void>;
    portal_attestation_policy_reportbypolicy_get(uidpolicy: string): MethodDescriptor<void>;
    portal_attestation_policy_run_post(uidpolicy: string, inputParameterName: PolicyStartInput): MethodDescriptor<void>;
    portal_attestation_policy_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, mypolicies: string): MethodDescriptor<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_delete(UID_AttestationPolicy: string): MethodDescriptor<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy: string): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, OnlyActivePolicies: string, ScheduleType: string, mypolicies: string): MethodDescriptor<GroupInfo[]>;
    portal_attestation_query_post(uidcase: string, inputParameterName: PwoQueryInput): MethodDescriptor<void>;
    portal_attestation_recalldecision_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_recallquery_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_report_get(uidcase: string): MethodDescriptor<Blob>;
    portal_attestation_resetreservation_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_revokeadditional_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_revokedelegation_post(uidcase: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_attestation_run_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, withpendingcases: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_run_approvers_get(uidrun: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_run_extend_post(uidrun: string, inputParameterName: ExtendRunInput): MethodDescriptor<void>;
    portal_attestation_run_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_attestation_run_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, withpendingcases: string): MethodDescriptor<GroupInfo[]>;
    portal_attestation_run_sendreminder_post(inputParameterName: SendReminderInput): MethodDescriptor<void>;
    portal_attestation_schedules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_attestation_schedules_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_attestation_schedules_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_attestation_snapshot_get(uidcase: string): MethodDescriptor<AttestationSnapshotData>;
    portal_attestation_stepup_post(inputParameterName: AttestationStepUpApprovalData): MethodDescriptor<string>;
    portal_attestation_userconfig_get(): MethodDescriptor<AttUserConfig>;
    portal_attestation_workflow_get(uidattestationcase: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AttestationPolicyGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AttestationPolicyGroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AttestationPolicyGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_ComplianceArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ComplianceArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_DialogTimeZone_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_DialogTimeZone_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QBMCulture_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QBMCulture_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_claimdevice_post(uidperson: string, uiddevice: string): MethodDescriptor<void>;
    portal_claimdevice_devices_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_config_get(): MethodDescriptor<ProjectConfig>;
    portal_featureconfig_get(): MethodDescriptor<FeatureConfig>;
    register_config_get(): MethodDescriptor<ATT_Person_SelfRegister_Config>;
    register_featureconfig_get(): MethodDescriptor<SelfRegisterConfig>;
    register_person_post(inputParameterName: ExtendedEntityWriteData<CaptchaCode>): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    admin_config_get(requestOptions?: ApiRequestOptions): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, requestOptions?: ApiRequestOptions): Promise<ApplicationMethodConfig>;
    imx_config_get(requestOptions?: ApiRequestOptions): Promise<ImxConfig>;
    opsupport_config_get(requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    opsupport_featureconfig_get(requestOptions?: ApiRequestOptions): Promise<FeatureConfig>;
    passwordreset_activation_confirm_post(inputParameterName: PasscodeInput, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    passwordreset_activation_init_post(uidcase: string, requestOptions?: ApiRequestOptions): Promise<PersonActivationDto>;
    passwordreset_activation_resendemail_post(requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_additional_post(uidcase: string, inputParameterName: OtherApproverInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_answerquery_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_get(Escalation: boolean, objecttable: string, objectuid: string, uid_attestationcase: string, uid_attestationhelper: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, attestationtype: string, uidpolicy: string, type: string, risk: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns the entitlements that a user will lose if the specified attestation case is denied. */
    portal_attestation_approve_losspreview_get(uid_case: string, requestOptions?: ApiRequestOptions): Promise<EntitlementLossDto[]>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/approve endpoint. */
    portal_attestation_approve_datamodel_get(Escalation: boolean, objecttable: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, attestationtype: string, uidpolicy: string, type: string, risk: string, Escalation: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_attestation_approve_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/approve/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_attestation_approve_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_case_get(objecttable: string, objectuid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, attestationtype: string, uidpolicy: string, type: string, risk: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns data model information about query options for the attestation/case endpoint. */
    portal_attestation_case_datamodel_get(objecttable: string, objectuid: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_case_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, attestationtype: string, uidpolicy: string, type: string, risk: string, objecttable: string, objectuid: string, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    /** Returns the workflow history for the specified attestation case. */
    portal_attestation_case_history_get(uidcase: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_attestation_case_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/case/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_attestation_case_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_config_get(requestOptions?: ApiRequestOptions): Promise<AttestationConfig>;
    portal_attestation_decide_post(uidcase: string, inputParameterName: DecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_denydecision_post(uidcase: string, inputParameterName: DenyDecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_directdecision_post(uidcase: string, inputParameterName: DirectDecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_escalate_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns candidate objects for a filter definition. */
    portal_attestation_filter_candidates_get(uidattestationparm: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns objects matching the filter. */
    portal_attestation_filter_matchingobjects_get(policyfilter: PolicyFilter, uidpickcategory: string, uidattestationobject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns configuration information for the specified parameter object. */
    portal_attestation_filter_model_get(uidobject: string, requestOptions?: ApiRequestOptions): Promise<AttestationObjectData>;
    portal_attestation_insteadof_post(uidcase: string, inputParameterName: OtherApproverInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Starts the attestation policy to define missing manager assignments for identities. The attestation cases are created asynchronously. */
    portal_attestation_managerattestation_post(requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_object_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns identities allowed to make approvals for the specified attestation case. */
    portal_attestation_persondecision_get(uidattestationcase: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_policy_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, OnlyActivePolicies: string, ScheduleType: string, mypolicies: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Creates a report containing information about the attestation run and its progress. */
    portal_attestation_policy_report_get(uidpolicy: string, uidrun: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about the attestation policy and its progress. */
    portal_attestation_policy_reportbypolicy_get(uidpolicy: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates attestation cases for the specified policy and objects */
    portal_attestation_policy_run_post(uidpolicy: string, inputParameterName: PolicyStartInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/policy endpoint. */
    portal_attestation_policy_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_policy_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, mypolicies: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_delete(UID_AttestationPolicy: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    /** Returns data model information about query options for the attestation/policy/edit endpoint. */
    portal_attestation_policy_edit_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_policy_edit_interactive_get(requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    /** Returns a list of objects that can be assigned to the property UID_AttestationObject. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_QERPickCategory/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_policy_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, OnlyActivePolicies: string, ScheduleType: string, mypolicies: string, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_attestation_query_post(uidcase: string, inputParameterName: PwoQueryInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_recalldecision_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_recallquery_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the PDF file associated with the specified attestation case. */
    portal_attestation_report_get(uidcase: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_attestation_resetreservation_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes a previously added additional approver. */
    portal_attestation_revokeadditional_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Revokes an approval delegation. */
    portal_attestation_revokedelegation_post(uidcase: string, inputParameterName: ReasonInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_run_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, withpendingcases: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_run_approvers_get(uidrun: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_run_extend_post(uidrun: string, inputParameterName: ExtendRunInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/run endpoint. */
    portal_attestation_run_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_run_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, withpendingcases: string, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_attestation_run_sendreminder_post(inputParameterName: SendReminderInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_schedules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_schedules_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_schedules_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the object state snapshot associated with the specified attestation case. */
    portal_attestation_snapshot_get(uidcase: string, requestOptions?: ApiRequestOptions): Promise<AttestationSnapshotData>;
    /** Initiates step-up authentication for the specified request. */
    portal_attestation_stepup_post(inputParameterName: AttestationStepUpApprovalData, requestOptions?: ApiRequestOptions): Promise<string>;
    portal_attestation_userconfig_get(requestOptions?: ApiRequestOptions): Promise<AttUserConfig>;
    portal_attestation_workflow_get(uidattestationcase: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AttestationPolicyGroup. */
    portal_candidates_AttestationPolicyGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AttestationPolicyGroup endpoint. */
    portal_candidates_AttestationPolicyGroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AttestationPolicyGroup endpoint. */
    portal_candidates_AttestationPolicyGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ComplianceArea. */
    portal_candidates_ComplianceArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ComplianceArea endpoint. */
    portal_candidates_ComplianceArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table DialogTimeZone. */
    portal_candidates_DialogTimeZone_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
    portal_candidates_DialogTimeZone_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QBMCulture. */
    portal_candidates_QBMCulture_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Triggers an ownership attestation for the specified device. */
    portal_claimdevice_post(uidperson: string, uiddevice: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of devices for which the user can trigger an ownership attestation. */
    portal_claimdevice_devices_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_config_get(requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    portal_featureconfig_get(requestOptions?: ApiRequestOptions): Promise<FeatureConfig>;
    register_config_get(requestOptions?: ApiRequestOptions): Promise<ATT_Person_SelfRegister_Config>;
    register_featureconfig_get(requestOptions?: ApiRequestOptions): Promise<SelfRegisterConfig>;
    register_person_post(inputParameterName: ExtendedEntityWriteData<CaptchaCode>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
export declare class V2ApiClientMethodFactory {
    admin_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ApplicationMethodConfig>;
    imx_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ImxConfig>;
    opsupport_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ProjectConfig>;
    opsupport_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FeatureConfig>;
    passwordreset_activation_confirm_post(inputParameterName: PasscodeInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SessionResponse>;
    passwordreset_activation_init_post(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<PersonActivationDto>;
    passwordreset_activation_resendemail_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_additional_post(uidcase: string, inputParameterName: OtherApproverInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_answerquery_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_approve_get(options?: {
        Escalation?: boolean;
        objecttable?: string;
        objectuid?: string;
        uid_attestationcase?: string;
        uid_attestationhelper?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_approve_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_approve_losspreview_get(uid_case: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntitlementLossDto[]>;
    portal_attestation_approve_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_approve_datamodel_get(options?: {
        Escalation?: boolean;
        objecttable?: string;
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_approve_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
        Escalation?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_attestation_approve_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_approve_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_case_get(options?: {
        objecttable?: string;
        objectuid?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<AttCaseDataRead>>;
    portal_attestation_case_datamodel_get(options?: {
        objecttable?: string;
        objectuid?: string;
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_case_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
        objecttable?: string;
        objectuid?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_attestation_case_history_get(uidcase: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_case_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_case_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<AttestationConfig>;
    portal_attestation_decide_post(uidcase: string, inputParameterName: DecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_denydecision_post(uidcase: string, inputParameterName: DenyDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_directdecision_post(uidcase: string, inputParameterName: DirectDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_escalate_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_filter_candidates_get(uidattestationparm: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_filter_matchingobjects_get(uidattestationobject: string, options?: {
        policyfilter?: PolicyFilter;
        uidpickcategory?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_filter_model_get(uidobject: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<AttestationObjectData>;
    portal_attestation_insteadof_post(uidcase: string, inputParameterName: OtherApproverInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_managerattestation_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_object_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_persondecision_get(uidattestationcase: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        OnlyActivePolicies?: string;
        ScheduleType?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_report_get(uidpolicy: string, uidrun: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_policy_reportbypolicy_get(uidpolicy: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_policy_run_post(uidpolicy: string, inputParameterName: PolicyStartInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_policy_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_delete(UID_AttestationPolicy: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_attestation_policy_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        OnlyActivePolicies?: string;
        ScheduleType?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_attestation_query_post(uidcase: string, inputParameterName: PwoQueryInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_recalldecision_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_recallquery_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_report_get(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_attestation_resetreservation_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_revokeadditional_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_revokedelegation_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_run_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withpendingcases?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_run_approvers_get(uidrun: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_run_extend_post(uidrun: string, inputParameterName: ExtendRunInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_run_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_attestation_run_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        withpendingcases?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_attestation_run_sendreminder_post(inputParameterName: SendReminderInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_schedules_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_schedules_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_attestation_schedules_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_attestation_snapshot_get(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<AttestationSnapshotData>;
    portal_attestation_stepup_post(inputParameterName: AttestationStepUpApprovalData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<string>;
    portal_attestation_userconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<AttUserConfig>;
    portal_attestation_workflow_get(uidattestationcase: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AttestationPolicyGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AttestationPolicyGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_candidates_AttestationPolicyGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_ComplianceArea_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ComplianceArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_DialogTimeZone_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_DialogTimeZone_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_MitigatingControl_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QBMCulture_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QBMCulture_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_claimdevice_post(uidperson: string, uiddevice: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_claimdevice_devices_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ProjectConfig>;
    portal_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FeatureConfig>;
    register_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ATT_Person_SelfRegister_Config>;
    register_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SelfRegisterConfig>;
    register_person_post(inputParameterName: ExtendedEntityWriteData<CaptchaCode>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    admin_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}, requestOptions?: ApiRequestOptions): Promise<ApplicationMethodConfig>;
    imx_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ImxConfig>;
    opsupport_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    opsupport_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<FeatureConfig>;
    passwordreset_activation_confirm_post(inputParameterName: PasscodeInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    passwordreset_activation_init_post(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<PersonActivationDto>;
    passwordreset_activation_resendemail_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_additional_post(uidcase: string, inputParameterName: OtherApproverInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_answerquery_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_get(options?: {
        Escalation?: boolean;
        objecttable?: string;
        objectuid?: string;
        uid_attestationcase?: string;
        uid_attestationhelper?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns the entitlements that a user will lose if the specified attestation case is denied. */
    portal_attestation_approve_losspreview_get(uid_case: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntitlementLossDto[]>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/approve endpoint. */
    portal_attestation_approve_datamodel_get(options?: {
        Escalation?: boolean;
        objecttable?: string;
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns attestation cases which the current user can decide. */
    portal_attestation_approve_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
        Escalation?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_attestation_approve_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/approve/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_attestation_approve_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_case_get(options?: {
        objecttable?: string;
        objectuid?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<AttCaseDataRead>>;
    /** Returns data model information about query options for the attestation/case endpoint. */
    portal_attestation_case_datamodel_get(options?: {
        objecttable?: string;
        objectuid?: string;
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_case_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        attestationtype?: string;
        uidpolicy?: string;
        type?: string;
        risk?: string;
        objecttable?: string;
        objectuid?: string;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    /** Returns the workflow history for the specified attestation case. */
    portal_attestation_case_history_get(uidcase: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_attestation_case_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/case/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_attestation_case_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<AttestationConfig>;
    portal_attestation_decide_post(uidcase: string, inputParameterName: DecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_denydecision_post(uidcase: string, inputParameterName: DenyDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_directdecision_post(uidcase: string, inputParameterName: DirectDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_escalate_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns candidate objects for a filter definition. */
    portal_attestation_filter_candidates_get(uidattestationparm: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns objects matching the filter. */
    portal_attestation_filter_matchingobjects_get(uidattestationobject: string, options?: {
        policyfilter?: PolicyFilter;
        uidpickcategory?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns configuration information for the specified parameter object. */
    portal_attestation_filter_model_get(uidobject: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<AttestationObjectData>;
    portal_attestation_insteadof_post(uidcase: string, inputParameterName: OtherApproverInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Starts the attestation policy to define missing manager assignments for identities. The attestation cases are created asynchronously. */
    portal_attestation_managerattestation_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_object_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns identities allowed to make approvals for the specified attestation case. */
    portal_attestation_persondecision_get(uidattestationcase: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_policy_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        OnlyActivePolicies?: string;
        ScheduleType?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Creates a report containing information about the attestation run and its progress. */
    portal_attestation_policy_report_get(uidpolicy: string, uidrun: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about the attestation policy and its progress. */
    portal_attestation_policy_reportbypolicy_get(uidpolicy: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates attestation cases for the specified policy and objects */
    portal_attestation_policy_run_post(uidpolicy: string, inputParameterName: PolicyStartInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/policy endpoint. */
    portal_attestation_policy_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_policy_edit_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    portal_attestation_policy_edit_delete(UID_AttestationPolicy: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyFilterData[]>>;
    /** Returns data model information about query options for the attestation/policy/edit endpoint. */
    portal_attestation_policy_edit_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_policy_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfPolicyFilterDataOf>;
    /** Returns a list of objects that can be assigned to the property UID_AttestationObject. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the attestation/policy/edit/interactive/UID_QERPickCategory/candidates endpoint. */
    portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_attestation_policy_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        OnlyActivePolicies?: string;
        ScheduleType?: string;
        mypolicies?: string;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_attestation_query_post(uidcase: string, inputParameterName: PwoQueryInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_recalldecision_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_recallquery_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the PDF file associated with the specified attestation case. */
    portal_attestation_report_get(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_attestation_resetreservation_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes a previously added additional approver. */
    portal_attestation_revokeadditional_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Revokes an approval delegation. */
    portal_attestation_revokedelegation_post(uidcase: string, inputParameterName: ReasonInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_run_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withpendingcases?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_run_approvers_get(uidrun: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_run_extend_post(uidrun: string, inputParameterName: ExtendRunInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the attestation/run endpoint. */
    portal_attestation_run_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_attestation_run_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        withpendingcases?: string;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_attestation_run_sendreminder_post(inputParameterName: SendReminderInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_attestation_schedules_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_schedules_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_attestation_schedules_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the object state snapshot associated with the specified attestation case. */
    portal_attestation_snapshot_get(uidcase: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<AttestationSnapshotData>;
    /** Initiates step-up authentication for the specified request. */
    portal_attestation_stepup_post(inputParameterName: AttestationStepUpApprovalData, options?: {}, requestOptions?: ApiRequestOptions): Promise<string>;
    portal_attestation_userconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<AttUserConfig>;
    portal_attestation_workflow_get(uidattestationcase: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AttestationPolicyGroup. */
    portal_candidates_AttestationPolicyGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AttestationPolicyGroup endpoint. */
    portal_candidates_AttestationPolicyGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AttestationPolicyGroup endpoint. */
    portal_candidates_AttestationPolicyGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ComplianceArea. */
    portal_candidates_ComplianceArea_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ComplianceArea endpoint. */
    portal_candidates_ComplianceArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table DialogTimeZone. */
    portal_candidates_DialogTimeZone_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
    portal_candidates_DialogTimeZone_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QBMCulture. */
    portal_candidates_QBMCulture_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Triggers an ownership attestation for the specified device. */
    portal_claimdevice_post(uidperson: string, uiddevice: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of devices for which the user can trigger an ownership attestation. */
    portal_claimdevice_devices_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    portal_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<FeatureConfig>;
    register_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ATT_Person_SelfRegister_Config>;
    register_featureconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<SelfRegisterConfig>;
    register_person_post(inputParameterName: ExtendedEntityWriteData<CaptchaCode>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
