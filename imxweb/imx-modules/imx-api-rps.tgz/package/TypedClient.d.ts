import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, FilterData, FilterPropertyList, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityStateData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ParameterData, SqlExpression, SqlWizardExpression, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfIReadOnlyListOfIReadOnlyListOfParameterData extends EntityCollectionData {
    ExtendedData?: ParameterData[][];
}
export interface ExtendedEntityCollectionDataOfListReportDefinitionRead extends EntityCollectionData {
    ExtendedData?: ListReportDefinitionRead;
}
export interface ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData extends InteractiveEntityData {
    ExtendedData?: ParameterData[][];
}
export interface ExtendedInteractiveEntityDataOfListReportDefinitionRead extends InteractiveEntityData {
    ExtendedData?: ListReportDefinitionRead;
}
export interface ExtendedInteractiveEntityWriteDataOfIReadOnlyListOfIReadOnlyListOfEntityWriteDataColumn extends InteractiveEntityWriteData {
    ExtendedData?: EntityWriteDataColumn[][];
}
export interface ExtendedInteractiveEntityWriteDataOfListReportDefinitionWrite extends InteractiveEntityWriteData {
    ExtendedData?: ListReportDefinitionWrite;
}
export interface ListReportColumn {
    Name?: string;
    Display?: string;
}
export interface ListReportDefinitionDto {
    TableName?: string;
    TableNameDisplay?: string;
    AvailableColumns?: ListReportColumn[];
    SelectedColumns?: string[];
    Data?: SqlWizardExpression;
}
export interface ListReportDefinitionDtoWrite {
    TableName?: string;
    SelectedColumns?: string[];
    Data?: SqlWizardWrite;
}
export interface ListReportDefinitionRead {
    Definition?: ListReportDefinitionDto[];
}
export interface ListReportDefinitionWrite {
    Definition?: ListReportDefinitionDtoWrite[];
}
export interface SqlWizardWrite {
    Filters?: SqlExpression[];
}
export declare class TypedClient {
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalReports: PortalReportsWrapper;
    readonly PortalReportsEdit: PortalReportsEditWrapper;
    readonly PortalReportsEditInteractive: PortalReportsEditInteractiveWrapper;
    readonly PortalReportsSqlwizardCandidates: PortalReportsSqlwizardCandidatesWrapper;
    readonly PortalReportsTables: PortalReportsTablesWrapper;
    readonly PortalShopConfigEntitlementsRpsreport: PortalShopConfigEntitlementsRpsreportWrapper;
    readonly PortalSubscription: PortalSubscriptionWrapper;
    readonly PortalSubscriptionInteractive: PortalSubscriptionInteractiveWrapper;
    readonly PortalSubscriptionInteractiveParameterCandidates: PortalSubscriptionInteractiveParameterCandidatesWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
export declare class PortalReports extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly IsOob: IReadValue<boolean>;
    readonly Subscriptions: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'IsListReport' | 'IsOob' | 'Subscriptions'>;
}
export declare class PortalReportsEdit extends WriteExtTypedEntity<ListReportDefinitionWrite> {
    readonly Description: IWriteValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly Ident_RPSReport: IWriteValue<string>;
    readonly AvailableTo: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'IsListReport' | 'Ident_RPSReport' | 'AvailableTo'>;
}
export declare class PortalReportsEditInteractive extends WriteExtTypedEntity<ListReportDefinitionWrite> {
    readonly Description: IWriteValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly Ident_RPSReport: IWriteValue<string>;
    readonly AvailableTo: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'IsListReport' | 'Ident_RPSReport' | 'AvailableTo'>;
}
export declare class PortalReportsSqlwizardCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalReportsTables extends TypedEntity {
    readonly TableName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'TableName'>;
}
export declare class PortalShopConfigEntitlementsRpsreport extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_RPSReport: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_RPSReport'>;
}
export declare class PortalSubscription extends WriteExtTypedEntity<EntityWriteDataColumn[][]> {
    readonly UID_RPSReport: IWriteValue<string>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    readonly ExportFormat: IWriteValue<string>;
    readonly Ident_RPSSubscription: IWriteValue<string>;
    readonly AddtlSubscribers: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_RPSReport' | 'UID_DialogSchedule' | 'ExportFormat' | 'Ident_RPSSubscription' | 'AddtlSubscribers'>;
}
export declare class PortalSubscriptionInteractive extends WriteExtTypedEntity<EntityWriteDataColumn[][]> {
    readonly UID_RPSReport: IWriteValue<string>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    readonly ExportFormat: IWriteValue<string>;
    readonly Ident_RPSSubscription: IWriteValue<string>;
    readonly AddtlSubscribers: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_RPSReport' | 'UID_DialogSchedule' | 'ExportFormat' | 'Ident_RPSSubscription' | 'AddtlSubscribers'>;
}
export declare class PortalSubscriptionInteractiveParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalReportsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        owned?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReports, unknown>>;
}
export declare class PortalReportsEditWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
    Delete(UID_RPSReport: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
}
export declare class PortalReportsEditInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalReportsEditInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
    Delete(inputParameterName: PortalReportsEditInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
    Get_byid(UID_RPSReport: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
}
export declare class PortalReportsSqlwizardCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(table: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsSqlwizardCandidates, unknown>>;
}
export declare class PortalReportsTablesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsTables, unknown>>;
}
export declare class PortalShopConfigEntitlementsRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsRpsreport;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsRpsreport, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
    Delete(UID_ITShopOrg: string, UID_RPSReport: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
}
export declare class PortalSubscriptionWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
    Delete(UID_RPSSubscription: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
}
export declare class PortalSubscriptionInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalSubscriptionInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractive, ParameterData[][]>>;
    Delete(inputParameterName: PortalSubscriptionInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractive, ParameterData[][]>>;
    Get_byid(UID_RPSSubscription: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractive, ParameterData[][]>>;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractive, ParameterData[][]>>;
}
export declare class PortalSubscriptionInteractiveParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalSubscriptionInteractiveParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractiveParameterCandidates, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_reports_get(owned: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_reports_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_delete(UID_RPSReport: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_reports_sqlwizard_tables_columns_get(table: string): MethodDescriptor<FilterPropertyList>;
    portal_reports_tables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_subscription_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_sendmail_post(uid: string): MethodDescriptor<void>;
    portal_subscription_sendmailcc_post(uid: string): MethodDescriptor<void>;
    portal_subscription_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, keys: string[], state: string, type: string): MethodDescriptor<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_RPSReport_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Manages reports owned by the current user, or subscribable by the current user. */
    portal_reports_get(owned: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_delete(UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_get(requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_reports_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_reports_sqlwizard_tables_columns_get(table: string, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_reports_tables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_subscription_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    /** Queues a job to e-mail the report to the subscriber. */
    portal_subscription_sendmail_post(uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    portal_subscription_sendmailcc_post(uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_subscription_interactive_get(requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, keys: string[], state: string, type: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_subscription_interactive_UID_RPSReport_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
export declare class V2ApiClientMethodFactory {
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_reports_get(options?: {
        owned?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_reports_edit_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_delete(UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_reports_sqlwizard_tables_columns_get(table: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterPropertyList>;
    portal_reports_tables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_subscription_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_sendmail_post(uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_subscription_sendmailcc_post(uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_subscription_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, options?: {
        keys?: string[];
        state?: string;
        type?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_RPSReport_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Manages reports owned by the current user, or subscribable by the current user. */
    portal_reports_get(options?: {
        owned?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_delete(UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. */
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_reports_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_reports_sqlwizard_tables_columns_get(table: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_reports_tables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_subscription_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    /** Queues a job to e-mail the report to the subscriber. */
    portal_subscription_sendmail_post(uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    portal_subscription_sendmailcc_post(uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_subscription_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, options?: {
        keys?: string[];
        state?: string;
        type?: string;
    }, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_subscription_interactive_UID_RPSReport_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
